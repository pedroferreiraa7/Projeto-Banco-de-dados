package Interfaces;

import Fila.Fila1;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Index extends JFrame implements ActionListener {

    JLabel ltexto, lfoto;
    JButton bsaldo, brecarregar,bsair;
    Fila1 fila;
    String url = "";
    String usuario ="admin";
    String senha  = "123";
  

    public Index() {
        intitComponent();
        try{
            Class.forName("");
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null,"Não Encontrado");
            
        }
        
        
        
         fila = new Fila1();
        Container fundo;
        fundo = this.getContentPane();
        fundo.setBackground(Color.gray);
     

        lfoto = new JLabel("");
        ImageIcon img1 = new ImageIcon("src/Imagens/assur.png");
        
        ltexto = new JLabel("Use passe");
        ltexto.setFont(new Font("Comic Sans MS", Font.PLAIN, 24));
        bsaldo = new JButton("Saldo");
        brecarregar = new JButton("Recarregar");
        bsair = new JButton("Sair");

        ltexto.setBounds(190, 1, 200, 200);
        bsaldo.setBounds(10, 500, 150, 50);
        brecarregar.setBounds(180, 500, 150, 50);
        lfoto.setBounds(180, 10, 600, 280);
        bsair.setBounds(350,500,150,50);

        this.add(lfoto);
        this.add(ltexto);
        this.add(bsaldo);
        this.add(brecarregar);
           this.add(bsair);

        bsaldo.addActionListener(this);
        brecarregar.addActionListener(this);
        bsair.addActionListener(this);

        this.setSize(600, 700);
      
        this.setLayout(null);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource().equals(bsaldo)) {
        TelaSaldo saldo = new TelaSaldo(fila);

        } else if (ae.getSource().equals(brecarregar)) {
            TelaRecarregar tela = new TelaRecarregar(fila);

        }
        else if (ae.getSource().equals(bsair)) {
           this.setVisible(false);

        }
        

    }

}

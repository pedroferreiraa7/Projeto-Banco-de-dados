package Interfaces;

import Contato.Contato;
import Fila.Fila1;
import com.sun.jdi.connect.spi.Connection;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class TelaRecarregar extends JFrame implements ActionListener {

    JLabel ltexto, lvalorrecarga, lcpf;
    JButton bsaldo, bpagamento;
    JTextField tvalorrecarga, tcpf;
    double valortotal = 0;
    Fila1 fila;
    public TelaRecarregar(Fila1 fila) {
        this.fila=fila;
        ltexto = new JLabel("Recarga Assur");
        ltexto.setFont(new Font("Comic Sans MS", Font.PLAIN, 24));

        lvalorrecarga = new JLabel("Valor da Recarga:");
        lcpf = new JLabel("Digite o Seu CPF:");

        tvalorrecarga = new JTextField("");
        tcpf = new JTextField("");
        bsaldo = new JButton("Saldo");
        bpagamento = new JButton("Pagar");

        ltexto.setBounds(160, 1, 200, 200);
        lvalorrecarga.setBounds(10, 50, 200, 200);
        tvalorrecarga.setBounds(140, 140, 100, 20);
        tcpf.setBounds(140, 210, 100, 20);
        bsaldo.setBounds(10, 350, 150, 50);
        bpagamento.setBounds(280, 350, 150, 50);
        lcpf.setBounds(10, 120, 200, 200);

        this.add(ltexto);
        this.add(lvalorrecarga);
        this.add(bsaldo);
        this.add(bpagamento);
        this.add(tvalorrecarga);
        this.add(lcpf);
        this.add(tcpf);

        bsaldo.addActionListener(this);
        bpagamento.addActionListener(this);

        this.setBounds(10, 10, 500, 500);
        this.setBackground(Color.gray);
        this.setLayout(null);
        this.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource().equals(bsaldo)) {
            TelaSaldo tela = new TelaSaldo(fila);
        }
        else if (ae.getSource().equals(bpagamento)) {
            if (valortotal == 11) {
                Contato contato = new Contato();
                contato.setValordarecarga(Integer.parseInt(tvalorrecarga.getText()));
                contato.setCpfrecarga(Integer.parseInt(tcpf.getText()));
                 contato.setValorTotal(valortotal);
                 
                 Connection conexao = DriveManager.getConnection(url,senha,usuario);
               
                fila.queue(contato);
                JOptionPane.showMessageDialog(null, "Pagamento Feito!");
                tcpf.setText(null);
                tvalorrecarga.setText(null);
                valortotal = 0;
            }

            
            else{
                 JOptionPane.showMessageDialog(null, "O cpf precisa ter 11 digitos, por favor insira novamente!!");
            }
        }

        

    }
}

package Exception;
public class Exception extends RuntimeException {
}

package Fila;
import Contato.Contato;
import java.util.ArrayList;

public class Fila1 {
    ArrayList dados;
 
    public Fila1(){
        dados = new ArrayList();
    }
    
    public void queue(Contato contato){
        dados.add(contato);
    }
    
    public Contato dequeue(){
        Contato temp = (Contato) dados.get(0);
        dados.remove(0);
        return temp;
    }
    public boolean isEmpty(){
        if(dados.isEmpty())
            return true;
        else
            return false;
    }
    public int size(){
        return dados.size();
        
    }
    public boolean hasMoreElements(){
        if(dados.size()>0)
            return true;
        else
            return false;
    }
}

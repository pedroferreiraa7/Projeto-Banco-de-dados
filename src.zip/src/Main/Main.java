package Main;

import Interfaces.Index;

public class Main {
    public static void main(String args []){
        Index index = new Index();
     
    }
    
}

package Contato;
public class Contato {
    private int valordarecarga;
    private int cpfrecarga;
    private int cpfsaldo;
    private int saldoatual;
    private double valorTotal;

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public int getValordarecarga() {
        return valordarecarga;
    }

    public void setValordarecarga(int valordarecarga) {
        this.valordarecarga = valordarecarga;
    }

    public int getCpfrecarga() {
        return cpfrecarga;
    }

    public void setCpfrecarga(int cpfrecarga) {
        this.cpfrecarga = cpfrecarga;
    }

    public int getCpfsaldo() {
        return cpfsaldo;
    }

    public void setCpfsaldo(int cpfsaldo) {
        this.cpfsaldo = cpfsaldo;
    }

    public int getSaldoatual() {
        return saldoatual;
    }

    public void setSaldoatual(int saldoatual) {
        this.saldoatual = saldoatual;
    }
}
